<?php use App\Components\Theme;?>
<!DOCTYPE HTML>

<html>
	<head>
<meta name="csrf-token" content="{{{ csrf_token() }}}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{{$website_title}}}</title>
<link rel="icon" href="{{{asset('uploads/favicon')}}}/{{{$website_favicon}}}" type="image/gif" sizes="16x16">
	


	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/animate.css')">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/icomoon.css') ">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/themify-icons.css') ">
	
	
	<link rel="stylesheet" href="{{{asset('themes/DefaultTheme/css/materialfonts.css')}}}" type='text/css'>
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="{{{asset('css/bootstrap3.3.6.min.css')}}}">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/magnific-popup.css')">



	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/owl.carousel.min.css') ">
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/owl.theme.default.min.css') ">

	<!-- Theme style  -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/trendy.css') ">
	
	<link rel="stylesheet" href="{{{asset('themes/DefaultTheme/css/flag.css')}}}" type="text/css"  />
	
	 <link href="https://cdn.jsdelivr.net/toastr/2.1.3/toastr.min.css" rel="stylesheet" type="text/css">
	 
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js" type="text/javascript"></script>

	<!-- Modernizr JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	
	 <link href="{{{asset('themes/DefaultTheme/css/LandingPageRegister.css')}}}" rel="stylesheet" type="text/css">
     <style>
	     
	     .profile_drop_menu
	     {
		     border: none !important;
	     }
            .loader {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
/*             background: url("@plugin_asset('LandingPagesPlugin/images/heart_small.gif')")  50% 50% no-repeat rgb(249,249,249); */
            opacity: 0.7;
            }
            .social_login_cnt{
            margin-top: 0px;
            }
            .btn--google {
            background: #dc5050;
            color: #fff;
            padding: 7px 20px 7px;
            border-radius: 35px;
            font-size: 1em;
            line-height: 1.3572;
            transition: background .2s,color .2s;
            margin-right: 4%;
            }
            .icongoogle {
            background-color: white;
            color: #dc5050;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            line-height: 1.5em;
            margin-right: 2%;
            margin: -2px 10px -6px 0;
            }
            .display_in_block {
            display: inline-block;
            }
            .profile_drop_menu {
            border-radius: 35px;
            color: rgba(0, 0, 0, 0.68);
            background: white;
            line-height: 4px;
            padding: 3px;
            border: 1px solid rgba(0, 0, 0, 0.61);
            }
            .social-dropdown-div-ul {
            top: 140%;
            left: -13px;
            padding: 8px 8px;
            border-radius: 11px;
            }
            .social-dropdown-div-ul>li>a {
            margin-bottom: 2px;
            }
            .btn--facebook {
            background: #3464d4;
            color: #fff;
            padding: 7px 24px 7px;
            border-radius: 35px;
            font-size: 1em;
            line-height: 1.3572;
            transition: background .2s,color .2s;
            }
            .iconfb {
            background-color: white;
            color: #3464D4;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            line-height: 1.5em;
            margin-right: 2%;
            margin: -2px 10px -6px 0;
            }
            .btn--facebook:hover {
            background: #2851AF !important;
            color: #fff !important;
            }
            .btn--google:hover {
            background: #BD3E3E !important;
            <meta name="csrf-token" content="{{{ csrf_token() }}}">
            color: #fff !important;
            }
            .dropdown-custom-styling {
            float: right;
            margin-right: 40%;
            margin-top: 0.3%;
            }
            .validation-error {
            color: #AD4646;
            display: none;
            margin-top:-9px;
            font-size:13px;
            }
            .liteoxide-purpose {
            font-weight: 400;
            font-size: 11px;
            opacity: 0.7;
            }
            .liteoxide-purpose {
            width: 87%;
            }
            .date-input-addon
            {
            padding-top:20px;
            }
            .social_p_margin
            {
            display:none;
            }
            #options
            {
            top:-20px;
            }
            .here-dropdown
            {
            width:106%;
            text-align:left;
            }
            .chatmeetdate-caret
            {
            float:right;
            margin-top:8px;
            }
            .border-red
            {
            border:2px solid red;
            }
            .alert-danger {
            border-radius: 4px;
            margin-bottom: 4px;
            padding-left: 9px;
            padding-top: 9px;
            padding-bottom: 9px;
            }
            
            .form_boxshadow
            {
/* 	            border-top: 10px solid #FBB448; */
            }
            
            #options > .btn
            {
	               padding: 6px 6px !important;
    border: 2px solid rgba(156, 145, 139, 0.02) !important;
    font-size: 14px !important;
    background: none !important
            }
            
             #options > ul
             {
	             background: rgba(14, 4, 4, 0.78);
             }
             
             #options > ul > li
             {
	             cursor: pointer;
	             }
             
             #options  ul li a:hover, #options  ul li a:focus, #options  ul li a:active {
				  color: rgb(255, 0, 90);
				}
            .display_block
            {
	            position: absolute;
right: 12%;
top: 0;
            }
            
            .form_padding
            {
	            padding: 0;
            }
            
            .form_bg
            {
	            background: rgba(2, 1, 1, 0.34);
            }
            .select-fancy-image
            {
	            background: none;
border: 1px solid #8a7c79;
box-shadow: none;
            }
            
            .multiselect
            {
	            background: none;
color: #999;
padding: 5px 0px 9px 3px;
border: 1px solid rgba(251, 240, 243, 0.16);
            }
            
            .sign_up_text a
            {
	            color: red;
            }
        </style>


	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><img src="{{{asset('uploads/logo')}}}/{{{$website_outerlogo}}}" width="140" alt="Logo"/></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
												
						<li class="btn-cta"><a href="{{{url('/login')}}}"><span>{{{trans('app.signin')}}}</span></a></li>
						

					</ul>
					
				</div>
			</div>
			<div class="form-group display_block">
		                        {{{Theme::render('top-header')}}}
		                    </div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url('@if($website_backgroundimage) {{{asset("uploads/backgroundimage/{$website_backgroundimage}")}}} @else @plugin_asset('LandingPagesPlugin/Trendy/images/2-faces.1.jpg') @endif')" data-stellar-background-ratio="0.3">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class=" @if($only_social_logins == 'true') col-md-12 makeitcenter @else col-md-7 mt-text animate-box @endif " data-animate-effect="fadeInUp">
							<h2 class="text1_lovoo">{{{trans_choice('LandingPagesPlugin.first_screen_main_heading_top',0)}}}</h2>
							<h1 class="text2_lovoo">{{{trans_choice('LandingPagesPlugin.first_screen_main_heading',1)}}}</h1>	
							
							<div class="text-center social_margin">
			                    {{{Theme::render('login')}}}
			                </div>
						</div>

						
						<div data-animate-effect="fadeInRight" class="col-md-12 col-md-push-1 animate-box form_margin form_bg form_padding form_width form_boxshadow" @if($only_social_logins == 'true') style="display:none" @endif>
             <form method = "POST" action = "{{{ URL::to('register') }}}"  id="registration-form" name="edit-profile" @if($only_social_logins == 'true') style="display:none" @endif>
                  <input type="hidden" name="_token" value="{{{ csrf_token() }}}" />
                  <input type="hidden" name="gender" value="" />
        <div class="col-md-12 form_margin form_bg form_padding  form_boxshadow border-left_pseudo" style="padding: 10px">
<!--             <h4 class="text_white text-center opacity_7 header_margin">{{{trans_choice('LandingPagesPlugin.signup_top',2)}}}</h4> -->
            <div class="alert alert-danger signup-error" style="display:none">
                <span onclick="this.parentElement.style.display='none'" class="w3-closebtn">&times;</span>
                <span class= "error-text"></span>
            </div>
            <div class="form-group form_group_margin-bottom">
              <input type="text" class="form-control remove_boxshadow input_height" name="name" id="name" placeholder="{{{trans('app.name')}}}" data-toggle="tooltip" title="Full Name Required" data-placement="right">
             </div>
             
            <div class="form-group form_group_margin-bottom">
              <input type="email" class="form-control remove_boxshadow input_height" name="username" id="email" placeholder="{{{trans('app.email')}}}" data-toggle="tooltip" title="Email Required" data-placement="right">
             </div>
              <div class="form-group form_group_margin-bottom">
               <div class="row">
                  <div class="col-md-12 col-xs-12">
	                  <span style="color: white;font-size: 13px;position: relative;bottom: 4px">{{{trans('app.dob')}}}</span>
                    <div class="input-group date input_max_width" style="bottom: 4px;">


 

										<div class="select select-fancy select-fancy-image" style="width: 60px;margin-right: 5px;"> <select class="dobpart" id="dobday" required=""></select></div>
										<div class="select select-fancy select-fancy-image" style="width: 78px;margin-right: 5px;"><select class="dobpart" id="dobmonth" required="" ></select></div>
										<div class="select select-fancy select-fancy-image" style="width: 60px"><select class="dobpart" id="dobyear" required=""></select>	  </div>
										  <input id="dob" name="dob" type="hidden" placeholder="{{{trans('app.dob')}}}" class="form-control input-md" required="">
										    

										  



                   </div>
             </div>
             
              
              </div>
              </div>
              
              <div class="form-group form_group_margin-bottom">
               <div class="row">
              
             
              <div class="col-md-12 col-xs-12" @if($maxmind_geoip_enabled) style="display:none" @endif>
                <input autocomplete="off" name="city" placeholder="{{{trans('app.city')}}}" class="form-control remove_boxshadow input_height input_max_width input_max_margin" id="txtPlaces1" type="text" data-toggle="tooltip" title="Location Required" data-placement="right">
                <input type="hidden" id="lat" name="lat" value=""/>
                         <input type="hidden" id="lng" name="lng" value=""/>
                         <input type="hidden" id="city" name="city" value=""/>
                         <input type="hidden" id="country" name="country" value=""/>
              </div>
              </div>
              </div>
              
              <div class="form-group form_group_margin-bottom">
                <input type="hidden" value="" id="gender_val" name="gender_val"/>
              <div class="row">
                @foreach($sections as $section)
                  @foreach($section->fields as $field)
                    @if($field->on_registration == 'yes' && $field->type == "dropdown")
                    <div class="col-md-6 col-xs-6">
                      <select  name="{{{ $field->code }}}" class="form-control remove_boxshadow input_height input_max_width input_max_margin" id="{{{$field->code}}}">
	                     <option data-value="0" value="0">{{{trans('custom_profile.'.$field->code )}}}</option>  
                         @foreach($field->field_options as $option)
                          <option data-value="{{{$option->code}}}" value="{{{$option->id}}}">{{{trans('custom_profile.'.$option->code)}}}</option>
                         @endforeach
                      </select>
                    </div>
                    @elseif($field->on_registration == 'yes' && $field->type == 'checkbox')

                        <div class="col-md-6 col-xs-6">

                          <select type="text" id="multiselect_checkbox" name="{{$field->code}}[]" data-nonSelectedText="{{{$field->code}}}" class="form-control multiselect multiselect-icon" multiple="multiple" role="multiselect"> 
	                          
	                          @foreach($field->field_options as $option)
                                
                                
                                <option value="{{$option->id}}" name="{{$field->code}}[]">{{trans("custom_profile.{$option->code}")}}</option>
                            @endforeach         
             
            </select> 
                        </div>
                        
                    @elseif($field->on_registration == 'yes')
                    <div class="col-md-6 col-xs-6">
                      <input type="text" id="" name="{{{$field->code}}}" value="" placeholder="{{{$field->name}}}"/>
                    </div>
                    @endif
                  @endforeach
                @endforeach

                @if($gender->on_registration == 'yes')
                  <div class="col-md-6 col-xs-6">
                    <select  name="{{{ $gender->code }}}" class="form-control remove_boxshadow input_height input_max_width input_max_margin" id="{{{$gender->code}}}">
                       @foreach($gender->field_options as $option)
                        <option data-value="{{{$option->code}}}" value="{{{$option->id}}}">{{{trans('custom_profile.'.$option->code)}}}</option>
                       @endforeach
                    </select>
                  </div>
                @endif
              
              </div>
              </div>
             <div class="form-group form_group_margin-bottom">
              
              <input type="password" class="form-control remove_boxshadow input_height" id="pwd1" name="password" placeholder="{{{trans('app.password')}}}" data-toggle="tooltip" title="Password Required" data-placement="right">
             </div>
             <div class="form-group form_group_margin-bottom">
              
              <input type="password" class="form-control remove_boxshadow input_height" id="pwd2" name="password_confirmation" placeholder="{{{trans('app.password_confirm')}}}" data-toggle="tooltip" title="Confirm Password Required" data-placement="right">
             </div>
             <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block   border_none signup_height">{{{trans('app.signup')}}}</button>
             </div>
              <div class="form-group">
                        <p class="sign_up_text text_white">{{{trans_choice('LandingPagesPlugin.signup_bottom', 6)}}}
                            <a href="@LandingPageUrl('terms_and_conditions')">{{{trans('LandingPagesPlugin.terms_and_conditions')}}}</a>
                            <a href="@LandingPageUrl('privacy_policy')">{{{trans('LandingPagesPlugin.privacy_policy')}}}</a>
                            <a href="@LandingPageUrl('cookie_policy')">{{{trans('LandingPagesPlugin.cookie_policy')}}}</a>
                        </p>
                    </div>
          </form>
           </div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>

	
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">{{{trans_choice('LandingPagesPlugin.middle_content_heading',0)}}}</h2>
					<p>{{{trans_choice('LandingPagesPlugin.app_available_market_place_heading_sub',3)}}}</p>
				</div>
			</div>
			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="@LandingPageImage('first_feature_image')" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="@LandingPageImage('first_feature_image')" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>{{{trans_choice('LandingPagesPlugin.middle_content_first_heading',0)}}}</h2>
							<p>{{{trans_choice('LandingPagesPlugin.middle_content_first_description',0)}}}</p>
							
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="@LandingPageImage('second_feature_image')" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="@LandingPageImage('second_feature_image')" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>{{{trans_choice('LandingPagesPlugin.middle_content_second_heading',0)}}}</h2>
							<p>{{{trans_choice('LandingPagesPlugin.middle_content_second_description',0)}}}</p>
							
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="@LandingPageImage('third_feature_image')" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="@LandingPageImage('third_feature_image')" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>{{{trans_choice('LandingPagesPlugin.middle_content_third_heading',0)}}}</h2>
							<p>{{{trans_choice('LandingPagesPlugin.middle_content_third_description',0)}}}</p>
							

						</div>
					</a>
				</div>


				

			</div>
		</div>
	</div>
	



	<div class="gtco-cover gtco-cover-sm" style="background-image: url(@plugin_asset('LandingPagesPlugin/Trendy/images/background-3.jpg'))"  data-stellar-background-ratio="0.3">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>&ldquo; 
{{{trans_choice('LandingPagesPlugin.testimonial_text',0)}}} 
&rdquo;</h1>
					
				</div>	
			</div>
		</div>
	</div>

	<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				 <div class="col-md-12 col_4_padding">
            <div class="row">
                <div class="col-md-4">
                    <div class="col-md-12 text-center">
                        <img class="text-center" src="@LandingPageImage('last_content_first_description')"/>
                        <p class="text-center">{{{trans_choice('LandingPagesPlugin.bottom_up_screen_left_sub_heading',19)}}}</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-12 text-center">
                        <img class="text-center" src="@LandingPageImage('last_content_second_description')"/>
                        <p class="text-center">{{{trans_choice('LandingPagesPlugin.bottom_up_screen_middle_sub_heading',20)}}}</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-12 text-center">
                        <img class="text-center" src="@LandingPageImage('last_content_third_description')"/>
                       <p class="text-center">{{{trans_choice('LandingPagesPlugin.bottom_up_screen_right_sub_heading',22)}}}</p>
                    </div>
                </div>
            </div>
        </div>
			</div>

		
		</div>
	</div>

	






<footer class="brand-footer u-text-center">
    <div class="container-responsive-lg">
        <h6 class="u-text-xs u-margin-y-sm">
         {{{trans_choice('LandingPagesPlugin.copyright',0)}}}
        </h6>
        <ul class="gtco-social-icons">
							<li><a href="@LandingPageUrl('facebook')"><i class="icon-facebook"></i></a></li>
							<li><a href="@LandingPageUrl('google_plus')"><i class="icon-google"></i></a></li>
							
						</ul>
    </div>
</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	 <script>
            $.ajaxSetup({ 
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               }
            })
        </script>   
	
	<!-- jQuery Easing -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.easing.1.3.js')"></script>
	<!-- Bootstrap -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/bootstrap.min.js')"></script>
	<!-- Waypoints -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.countTo.js	')"></script>
	
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.waypoints.min.js')"></script>
	<!-- Carousel -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/owl.carousel.min.js')"></script>
	

	<!-- Stellar Parallax -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.stellar.min.js')"></script>

	<!-- Magnific Popup -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.magnific-popup.min.js')"></script>
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/magnific-popup-options.js') "></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.14.1/moment.min.js"></script>
	
	<script src="https://cdn.jsdelivr.net/toastr/2.1.3/toastr.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
	<!-- Main -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/main.js')"></script>
	
	 <script>
            $('#gender_val').val( $("select[name='gender'] option:selected" ).data('value'));
              
              $("select[name='gender']").on('change',function(){
                $('#gender_val').val( $( "select[name='gender'] option:selected" ).data('value'));
            }); 
            
        </script>
        <script>
            $.ajaxSetup({
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               }
            })
        </script>   
        <script>
            $(document).ready(function() {
              $(window).keydown(function(event){
                if(event.keyCode == 13) {
                  event.preventDefault();
                  return false;
                }
              });
            });
            // $(document).ready(function(){
            
            
            // $('.dropdown-menu a').on('click', function(){    
            //     $(this).parent().parent().prev().html($(this).html() + '<span class="caret"></span>');    
            // });
            // });
        </script>
        <script>
            $(document).ready(function(){
              /*
              $('#edit-profile').validate({
                    rules: {
                        firstname: {
                            minlength: 3,
                            required: true
                        },
                        lastname: {
                            minlength: 3,
                            required: true
                        },
                        username: {
                            required: true,
                            email: true
                        },
                        city: {
                            required: true
                          },
                        dob:{
                          required:true
                        },  
                        password: {
                            minlength: 4,
                            required: true
                        },
                       password_confirm:{
                          minlength:4,
                          required:true
                        }
                       
                    },
                    highlight: function (element) {
                        $(element).closest('.control-group').removeClass('success').addClass('error');
                      },
                    success: function (element) {
                        element.text('OK!').addClass('valid')
                            .closest('.control-group').removeClass('error').addClass('success');
                    }
                }); */
            });
        </script>    
        <script type="text/javascript">
            $(document).ready(function()
{
$("#registration-form").submit(function(e){
e.preventDefault();
$('.loader').fadeIn();
$(".validation-error").hide();
var name = $("#name").val();
var email = $("#email").val();
var dob = $("#dob").val();
var location = $("#txtPlaces1").val();
var password = $("#pwd1").val();
var confirm_password = $("#pwd2").val();
var flag = 0;
if(name == ''){
//$("#name").addClass('border-red');
$(".signup-error > .error-text").html("{{{trans_choice('app.name_required',0)}}}");
$(".signup-error").show();
//$("#name").attr("placeholder","{{{trans('app.name')}}}");
flag = 1;
$('.loader').fadeOut();return;
}
if(dob == ''){
$(".signup-error > .error-text").html("{{{trans_choice('app.dob_required',0)}}}");
$(".signup-error").show();
//$("#dob").addClass('border-red');
$("#dob").attr("placeholder","{{{trans('app.dob_required')}}}");
flag = 1;
$('.loader').fadeOut();return;
}
if(email == ''){
$(".signup-error > .error-text").html("{{{trans_choice('app.email_required',0)}}}");
$(".signup-error").show();
// $("#email").addClass('border-red');
$("#email").attr("placeholder","{{{trans('app.email_required')}}}");
flag = 1;
$('.loader').fadeOut();return;
}
else if(!/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/.test(email)){
$(".signup-error > .error-text").html("{{{trans_choice('app.valid_email',0)}}}");
$(".signup-error").show();
// $('#email').addClass('border-red');
// $("#email").attr("placeholder","{{{trans('app.valid_email')}}}");
flag = 1;
$('.loader').fadeOut();return;
}
/*
if(location == ''){
$(".signup-error > .error-text").html("{{{trans_choice('app.location_required',0)}}}");
$(".signup-error").show();
// $("#txtPlaces1").addClass('border-red');
// $("#txtPlaces1").attr("placeholder","{{{trans('app.location_required')}}}");
flag = 1;
$('.loader').fadeOut();return;
}
*/
if(password == '')
{
$(".signup-error > .error-text").html("{{{trans_choice('app.password_validate_field',0)}}}");
$(".signup-error").show();
flag = 1;
$('.loader').fadeOut();return;
// $("#pwd1").addClass('border-red');
// $("#pwd1").attr("placeholder","{{{trans_choice('app.password_validate_field',0)}}}");
}
else if(password.length < 8){
$(".signup-error > .error-text").html("{{{trans_choice('app.password_validate_field',1)}}}");
$(".signup-error").show();
// $("#pwd1").addClass('border-red');
// $("#pwd1").attr("placeholder","P{{{trans_choice('app.password_validate_field',1)}}}");
flag = 1;
$('.loader').fadeOut();return;
}
else if(password != confirm_password){
$(".signup-error > .error-text").html("{{{trans_choice('app.password_validate_field',2)}}}");
$(".signup-error").show();
// $("#pwd2").addClass('border-red');
// $("#pwd1").attr("placeholder","{{{trans_choice('app.password_validate_field',2)}}}");
flag = 1;
$('.loader').fadeOut();return;
}
if(flag == 0){
$.ajax({
type: 'post',
url: '{{{url('/register')}}}',
data: $(this).serialize(),
success: function (response) {
$('.loader').fadeOut();
if(response.errors) { 
if(response.errors.dob) {
$(".signup-error > .error-text").html(response.errors.dob);
$(".signup-error").show();
// toastr.error(response.errors.dob);
// $('#dob').addClass('border-red');
}
if(response.errors.username) {
$(".signup-error > .error-text").html(response.errors.username);
$(".signup-error").show();
// //$("#email-error").show().html(response.errors.username);
//                                     toastr.error(response.errors.username);
}
if(response.errors.city || response.errors.country || response.errors.lat || response.errors.lng)
{
$(".signup-error > .error-text").html("{{{trans('app.city_select_suggestion')}}}");
$(".signup-error").show();
// //$('#location-error-para').show().html('City must be selected from suggestion!');
//                               toastr.error("{{{trans('app.city_select_suggestion')}}}");
}
}
else
{
if(response.email_verify_required)
{
toastr.info("{{{trans('app.email_verify_required')}}}");
toastr.success("{{{trans('app.registration_success')}}}");
}
else
{
toastr.success("{{{trans('app.registration_success')}}}");
window.location.href = "{{{ url('/login') }}}";
}
}
}
});
}
});
});
        </script>
        <script>
            new WOW().init();
        </script>
        <script src="@plugin_asset('LandingPagesPlugin/js/bootstrap-datepicker.js')"></script>
        <script>
            $(document).ready(function() {
                $('#datetimepicker')
                    .datepicker({
                        format: 'dd/mm/yyyy'
                    });
              });
                   
        </script>
        <script type="text/javascript">
            $(window).load(function() {
                $(".loader").fadeOut("slow");
            })
            
            
            
        </script>
        <script>
            $(document).ready(function()
            {
            $('.form-control').on('focus blur', function (e) {
               $(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
            }).trigger('blur');
            });
        </script>  
        <script>
            $(document).ready(function()
            {
              $('#datetimepicker').on('changeDate', function(ev){
              $(this).datepicker('hide');
              $("#dob").focus();
            
            });
            });
        </script>
        <script>
            $(document).ready(function() {
            $(window).keydown(function(event){
            if(event.keyCode == 13) {
             event.preventDefault();
             return false;
            }
            });
            });
        </script>
       <script type="text/javascript">
  /* jQuery DOB Picker 1.0 | Tom Yeadon | https://github.com/tyea/dobpicker | MIT License */
jQuery.extend({dobPicker:function(e){if(typeof e.dayDefault==="undefined")e.dayDefault="Day";if(typeof e.monthDefault==="undefined")e.monthDefault="Month";if(typeof e.yearDefault==="undefined")e.yearDefault="Year";if(typeof e.minimumAge==="undefined")e.minimumAge=12;if(typeof e.maximumAge==="undefined")e.maximumAge=80;$(e.daySelector).append('<option value="">'+e.dayDefault+"</option>");$(e.monthSelector).append('<option value="">'+e.monthDefault+"</option>");$(e.yearSelector).append('<option value="">'+e.yearDefault+"</option>");for(i=1;i<=31;i++){if(i<=9){var t="0"+i}else{var t=i}$(e.daySelector).append('<option value="'+t+'">'+i+"</option>")}var n=["{{{trans('LandingPagesPlugin.january')}}}","{{{trans('LandingPagesPlugin.february')}}}","{{{trans('LandingPagesPlugin.march')}}}","{{{trans('LandingPagesPlugin.april')}}}","{{{trans('LandingPagesPlugin.may')}}}","{{{trans('LandingPagesPlugin.june')}}}","{{{trans('LandingPagesPlugin.july')}}}","{{{trans('LandingPagesPlugin.august')}}}","{{{trans('LandingPagesPlugin.september')}}}","{{{trans('LandingPagesPlugin.october')}}}","{{{trans('LandingPagesPlugin.november')}}}","{{{trans('LandingPagesPlugin.december')}}}"];for(i=1;i<=12;i++){if(i<=9){var t="0"+i}else{var t=i}$(e.monthSelector).append('<option value="'+t+'">'+n[i-1]+"</option>")}var r=new Date;var s=r.getFullYear();var o=s-e.minimumAge;var u=o-e.maximumAge;for(i=o;i>=u;i--){$(e.yearSelector).append('<option value="'+i+'">'+i+"</option>")}$(e.daySelector).change(function(){$(e.monthSelector)[0].selectedIndex=0;$(e.yearSelector)[0].selectedIndex=0;$(e.yearSelector+" option").removeAttr("disabled");if($(e.daySelector).val()>=1&&$(e.daySelector).val()<=29){$(e.monthSelector+" option").removeAttr("disabled")}else if($(e.daySelector).val()==30){$(e.monthSelector+" option").removeAttr("disabled");$(e.monthSelector+' option[value="02"]').attr("disabled","disabled")}else if($(e.daySelector).val()==31){$(e.monthSelector+" option").removeAttr("disabled");$(e.monthSelector+' option[value="02"]').attr("disabled","disabled");$(e.monthSelector+' option[value="04"]').attr("disabled","disabled");$(e.monthSelector+' option[value="06"]').attr("disabled","disabled");$(e.monthSelector+' option[value="09"]').attr("disabled","disabled");$(e.monthSelector+' option[value="11"]').attr("disabled","disabled")}});$(e.monthSelector).change(function(){$(e.yearSelector)[0].selectedIndex=0;$(e.yearSelector+" option").removeAttr("disabled");if($(e.daySelector).val()==29&&$(e.monthSelector).val()=="02"){$(e.yearSelector+" option").each(function(e){if(e!==0){var t=$(this).attr("value");var n=!(t%4||!(t%100)&&t%400);if(n===false){$(this).attr("disabled","disabled")}}})}})}})
  </script>
	
	
	<script>
	$(document).ready(function(){
	  $.dobPicker({
	    daySelector: '#dobday', /* Required */
	    monthSelector: '#dobmonth', /* Required */
	    yearSelector: '#dobyear', /* Required */
	    dayDefault: '{{{trans('LandingPagesPlugin.day')}}}', /* Optional */
	    monthDefault: '{{{trans('LandingPagesPlugin.month')}}}', /* Optional */
	    yearDefault: '{{{trans('LandingPagesPlugin.year')}}}', /* Optional */
	    minimumAge: 8, /* Optional */
	    maximumAge: 100 /* Optional */
	  });
	});
	</script>
	
	<script>
		$('.dobpart').on('change',function(){
			
			
			$('#dob').val($('#dobday').val()+'/'+$('#dobmonth').val()+'/'+$('#dobyear').val());
			
		})
		
				
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        if($('#multiselect_checkbox').length)
	    {
	        $('#multiselect_checkbox').multiselect({
		        nonSelectedText: $('#multiselect_checkbox').attr('data-nonselectedtext')
	        });
        }
    });
</script>
	
	
	@if($auto_browser_geolocation=='true')
<script type="text/javascript">
	
    $(document).ready(function() {
	    
	    getLocation();
	    
	    
	    //make loction disabled
	    if($('#txtPlaces1').length)
	    	$('#txtPlaces1').attr('disabled','disbaled');
	    
	    function getLocation() {
		    if (navigator.geolocation) {
		        navigator.geolocation.getCurrentPosition(showPosition,showError);
		    } else { 
		        toastr.info("Geolocation is not supported by this browser.");
		    }
		}
		
		 
		 
		 function showPosition(position) {
		    //toastr.info("Latitude: " + position.coords.latitude +"<br>Longitude: " + position.coords.longitude);
		    
		    codeLatLng(position.coords.latitude, position.coords.longitude);
		 }
		 
		 
		 function showError(error) {
		    switch(error.code) {
		        case error.PERMISSION_DENIED:
		            toastr.error("User denied the request for Geolocation.");
		            break;
		        case error.POSITION_UNAVAILABLE:
		            toastr.error("Location information is unavailable.").
		            break;
		        case error.TIMEOUT:
		            toastr.error("The request to get user location timed out.").
		            break;
		        case error.UNKNOWN_ERROR:
		            toastr.error("An unknown error occurred.").
		            break;
		    }
		}
		
		
		
		
		
		 function codeLatLng(lat, lng) {
			 
			 //assign values to hidden fields
			 $('#lat').val(lat);
			 $('#lng').val(lng);
			 
			  geocoder = new google.maps.Geocoder();

			var latlng = new google.maps.LatLng(lat, lng);
			geocoder.geocode({latLng: latlng}, function(results, status) {
			    if (status == google.maps.GeocoderStatus.OK) {
			      if (results[1]) {
			        var arrAddress = results;
			        
			        $.each(arrAddress, function(i, address_component) {
			          if (address_component.types[0] == "locality") {
			            console.log("City: " + address_component.address_components[0].long_name);
			            itemLocality = address_component.address_components[0].long_name;
			            
			            
			            
			            $('#city').val(itemLocality);
			            
			            
			            
			          }
			          
			          if (address_component.types[0] == "country") {
			            
			            country = address_component.address_components[0].long_name;
			            
			            
			            $('#country').val(country);
			           
			          }
			          
			        });
			        
			        if($('#txtPlaces1').length)
			            	$('#txtPlaces1').val(itemLocality+' '+country);
			        
			        
			      } else {
			        toastr.error("No results found");
			      }
			    } else {
			      toastr.error("Geocoder failed due to: " + status);
			    }
			});
		}
		
	    
    });
</script>
@endif

	</body>
</html>

