<?php use App\Components\Theme;?>
<!DOCTYPE HTML>

<html>
	<head>
<meta name="csrf-token" content="{{{ csrf_token() }}}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{{$website_title}}}</title>
	
<link rel="icon" href="{{{asset('uploads/favicon')}}}/{{{$website_favicon}}}" type="image/gif" sizes="16x16">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/animate.css')">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/icomoon.css') ">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/themify-icons.css') ">
	
	
	<link rel="stylesheet" href="{{{asset('themes/DefaultTheme/css/materialfonts.css')}}}" type='text/css'>
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="{{{asset('css/bootstrap3.3.6.min.css')}}}">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/magnific-popup.css')">



	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/owl.carousel.min.css') ">
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/owl.theme.default.min.css') ">

	<!-- Theme style  -->
	<link rel="stylesheet" href="@plugin_asset('LandingPagesPlugin/Trendy/css/trendy.css') ">
	
	<link rel="stylesheet" href="{{{asset('themes/DefaultTheme/css/flag.css')}}}" type="text/css"  />
	
	 <link href="https://cdn.jsdelivr.net/toastr/2.1.3/toastr.min.css" rel="stylesheet" type="text/css">
	 
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js" type="text/javascript"></script>

	<!-- Modernizr JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	
	<link href="{{{asset('themes/DefaultTheme/css/LandingPageSignIn.css')}}}" rel="stylesheet">
     <style>
	     
	     .profile_drop_menu
	     {
		     border: none !important;
	     }
            .loader {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
/*             background: url("@plugin_asset('LandingPagesPlugin/images/heart_small.gif')")  50% 50% no-repeat rgb(249,249,249); */
            opacity: 0.7;
            }
            .social_login_cnt{
            margin-top: 0px;
            }
            .btn--google {
            background: #dc5050;
            color: #fff;
            padding: 7px 20px 7px;
            border-radius: 35px;
            font-size: 1em;
            line-height: 1.3572;
            transition: background .2s,color .2s;
            margin-right: 4%;
            }
            .icongoogle {
            background-color: white;
            color: #dc5050;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            line-height: 1.5em;
            margin-right: 2%;
            margin: -2px 10px -6px 0;
            }
            .display_in_block {
            display: inline-block;
            }
            .profile_drop_menu {
            border-radius: 35px;
            color: rgba(0, 0, 0, 0.68);
            background: white;
            line-height: 4px;
            padding: 3px;
            border: 1px solid rgba(0, 0, 0, 0.61);
            }
            .social-dropdown-div-ul {
            top: 140%;
            left: -13px;
            padding: 8px 8px;
            border-radius: 11px;
            }
            .social-dropdown-div-ul>li>a {
            margin-bottom: 2px;
            }
            .btn--facebook {
            background: #3464d4;
            color: #fff;
            padding: 7px 24px 7px;
            border-radius: 35px;
            font-size: 1em;
            line-height: 1.3572;
            transition: background .2s,color .2s;
            }
            .iconfb {
            background-color: white;
            color: #3464D4;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            line-height: 1.5em;
            margin-right: 2%;
            margin: -2px 10px -6px 0;
            }
            .btn--facebook:hover {
            background: #2851AF !important;
            color: #fff !important;
            }
            .btn--google:hover {
            background: #BD3E3E !important;
            <meta name="csrf-token" content="{{{ csrf_token() }}}">
            color: #fff !important;
            }
            .dropdown-custom-styling {
            float: right;
            margin-right: 40%;
            margin-top: 0.3%;
            }
            .validation-error {
            color: #AD4646;
            display: none;
            margin-top:-9px;
            font-size:13px;
            }
            .liteoxide-purpose {
            font-weight: 400;
            font-size: 11px;
            opacity: 0.7;
            }
            .liteoxide-purpose {
            width: 87%;
            }
            .date-input-addon
            {
            padding-top:20px;
            }
            .social_p_margin
            {
            display:none;
            }
            #options
            {
            top:-20px;
            }
            .here-dropdown
            {
            width:106%;
            text-align:left;
            }
            .chatmeetdate-caret
            {
            float:right;
            margin-top:8px;
            }
            .border-red
            {
            border:2px solid red;
            }
            .alert-danger {
            border-radius: 4px;
            margin-bottom: 4px;
            padding-left: 9px;
            padding-top: 9px;
            padding-bottom: 9px;
            }
            
            .form_boxshadow
            {
/* 	            border-top: 10px solid #FBB448; */
            }
            
            #options > .btn
            {
	               padding: 6px 6px !important;
    border: 2px solid rgba(156, 145, 139, 0.02) !important;
    font-size: 14px !important;
    background: none !important
            }
            
             #options > ul
             {
	             background: rgba(14, 4, 4, 0.78);
             }
             
             #options > ul > li
             {
	             cursor: pointer;
	             }
             
             #options  ul li a:hover, #options  ul li a:focus, #options  ul li a:active {
				  color: rgb(255, 0, 90);
				}
            .display_block
            {
	            position: absolute;
right: 12%;
top: 0;
            }
            
            .sign_up_text a
            {
	            color: red;
            }
        </style>


	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><img src="{{{asset('uploads/logo')}}}/{{{$website_outerlogo}}}" width="140" alt="Logo"/></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
												
						<li class="btn-cta"><a href="{{{url('/register')}}}"><span>{{{trans('app.signup')}}}</span></a></li>
						

					</ul>
					
				</div>
			</div>
			<div class="form-group display_block">
		                        {{{Theme::render('top-header')}}}
		                    </div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url('@if($website_backgroundimage) {{{asset("uploads/backgroundimage/{$website_backgroundimage}")}}} @else @plugin_asset('LandingPagesPlugin/Trendy/images/2-faces.1.jpg') @endif')" data-stellar-background-ratio="0.3">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class=" @if($only_social_logins == 'true') col-md-12 makeitcenter @else col-md-7 mt-text animate-box @endif " data-animate-effect="fadeInUp">
							<h2 class="text1_lovoo">{{{trans_choice('LandingPagesPlugin.first_screen_main_heading_top',0)}}}</h2>
							<h1 class="text2_lovoo">{{{trans_choice('LandingPagesPlugin.first_screen_main_heading',1)}}}</h1>	
							
							<div class="text-center social_margin">
			                    {{{Theme::render('login')}}}
			                </div>
						</div>

						
						<div data-animate-effect="fadeInRight" class="col-md-4 col-md-push-1 animate-box form_margin form_bg form_padding form_width form_boxshadow" @if($only_social_logins == 'true') style="display:none" @endif>
            <form id="form1" action = "{{{ URL::to('login') }}}" method = "POST" class="">
              {!! csrf_field() !!} 
              <input type = "hidden" value = "" id = "lat" name = "lat">
              <input type = "hidden" value = "" id = "lng" name = "longi">
                      
              @if(session()->has('message'))
                              <div class="alert-danger">
                                  {{{session('message')}}}{{{session()->forget('message')}}}
                              </div>
                            @elseif(session()->has('emailChange'))
                              <div class="alert-danger">
                                 {{{session('emailChange')}}}
                                 {{{session()->forget('emailChange')}}}
                              </div>         
                            @endif
            <div class="form-group form_group_margin-bottom">
              <input type="email" readonly onfocus="this.removeAttribute('readonly');" class="form-control remove_boxshadow input_height" name="username" id="email" placeholder="{{{trans('app.email')}}}">
             </div>
              
            
             <div class="form-group form_group_margin-bottom">
              
              <input type="password" readonly onfocus="this.removeAttribute('readonly');" class="form-control remove_boxshadow input_height" id="pwd1" name="password" placeholder="{{{trans('app.password')}}}">
             </div>

             <div class="form-group" style="position:relative">
              <input type="checkbox" class="form-control remember-me-checkbox" name="remember_me" style="width:auto;">
              <span style="position: absolute;top: 10px;margin-left: 25px;color: white;width: 100%;font-size:16px">{{{trans('LandingPagesPlugin.remember_me')}}}</span>
             </div>


             
             <div class="form-group">
              <button type="submit" class="btn btn-primary btn-block   border_none signup_height">{{{trans('app.signin')}}}</button>
             </div>
             <div class="form-group">
                        <p class="sign_up_text text_white">{{{trans_choice('LandingPagesPlugin.signup_bottom', 6)}}}
                            <a href="@LandingPageUrl('terms_and_conditions')">{{{trans('LandingPagesPlugin.terms_and_conditions')}}}</a>
                            <a href="@LandingPageUrl('privacy_policy')">{{{trans('LandingPagesPlugin.privacy_policy')}}}</a>
                            <a href="@LandingPageUrl('cookie_policy')">{{{trans('LandingPagesPlugin.cookie_policy')}}}</a>
                        </p>
                    </div>
             @if($show_forgot_password_link)
              	<a id="forgot-password-link" href="#/" class="forgetPassword" >{{{trans('LandingPagesPlugin.forgot_password_link_text')}}}</a>
             @endif
          </form>
          <form id="forgot-password-form" action="{{{url('/forgotPassword/submit')}}}" method="POST" style="display:none;">
                         {!! csrf_field() !!} 
                        <div class="row">
                          
                            <div class="col-md-12">
                              <div class="form-group">
                                 
                              <input type="text" name="username" id="username_forgotpwd" class="form-control remove_boxshadow input_height" placeholder="{{{trans('app.email')}}}" required>
                              </div>
                            </div>
                            
                            <div class="col-md-12">
                              <div class="form-group ">
                                 <p class="text_white">{{{trans('LandingPagesPlugin.reset_password_text')}}}</p> 
                              
                              </div>
                            </div>
                           
                            <div class="col-md-12">
                              <a href="{{{url('/login')}}}" class="rememberPassword" >{{{trans('LandingPagesPlugin.remember_password_link_text')}}}</a>
                             <button type="submit" class="btn btn-primary border_none btn_signup_bg pull-right" id="reset">{{{trans('LandingPagesPlugin.reset_password_button_text')}}}</button>
                            </div>
                          </div>
                       </form>
           </div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>

	
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">{{{trans_choice('LandingPagesPlugin.middle_content_heading',0)}}}</h2>
					<p>{{{trans_choice('LandingPagesPlugin.app_available_market_place_heading_sub',3)}}}</p>
				</div>
			</div>
			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="@LandingPageImage('first_feature_image')" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="@LandingPageImage('first_feature_image')" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>{{{trans_choice('LandingPagesPlugin.middle_content_first_heading',0)}}}</h2>
							<p>{{{trans_choice('LandingPagesPlugin.middle_content_first_description',0)}}}</p>
							
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="@LandingPageImage('second_feature_image')" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="@LandingPageImage('second_feature_image')" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>{{{trans_choice('LandingPagesPlugin.middle_content_second_heading',0)}}}</h2>
							<p>{{{trans_choice('LandingPagesPlugin.middle_content_second_description',0)}}}</p>
							
						</div>
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="@LandingPageImage('third_feature_image')" class="fh5co-card-item image-popup">
						<figure>
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="@LandingPageImage('third_feature_image')" alt="Image" class="img-responsive">
						</figure>
						<div class="fh5co-text">
							<h2>{{{trans_choice('LandingPagesPlugin.middle_content_third_heading',0)}}}</h2>
							<p>{{{trans_choice('LandingPagesPlugin.middle_content_third_description',0)}}}</p>
							

						</div>
					</a>
				</div>


				

			</div>
		</div>
	</div>
	



	<div class="gtco-cover gtco-cover-sm" style="background-image: url(@plugin_asset('LandingPagesPlugin/Trendy/images/background-3.jpg'))"  data-stellar-background-ratio="0.3">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>&ldquo; 

{{{trans_choice('LandingPagesPlugin.testimonial_text',0)}}} 
&rdquo;</h1>
					
				</div>	
			</div>
		</div>
	</div>

	<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				 <div class="col-md-12 col_4_padding">
            <div class="row">
                <div class="col-md-4">
                    <div class="col-md-12 text-center">
                        <img class="text-center" src="@LandingPageImage('last_content_first_description')"/>
                        <p class="text-center">{{{trans_choice('LandingPagesPlugin.bottom_up_screen_left_sub_heading',19)}}}</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-12 text-center">
                        <img class="text-center" src="@LandingPageImage('last_content_second_description')"/>
                        <p class="text-center">{{{trans_choice('LandingPagesPlugin.bottom_up_screen_middle_sub_heading',20)}}}</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="col-md-12 text-center">
                        <img class="text-center" src="@LandingPageImage('last_content_third_description')"/>
                       <p class="text-center">{{{trans_choice('LandingPagesPlugin.bottom_up_screen_right_sub_heading',22)}}}</p>
                    </div>
                </div>
            </div>
        </div>
			</div>

		
		</div>
	</div>

	





<footer class="brand-footer u-text-center">
    <div class="container-responsive-lg">
        <h6 class="u-text-xs u-margin-y-sm">
        {{{trans_choice('LandingPagesPlugin.copyright',0)}}}
        </h6>
        <ul class="gtco-social-icons">
							<li><a href="@LandingPageUrl('facebook')"><i class="icon-facebook"></i></a></li>
							<li><a href="@LandingPageUrl('google_plus')"><i class="icon-google"></i></a></li>
							
						</ul>
    </div>
</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	 <script>
            $.ajaxSetup({ 
               headers: {
                   'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               }
            })
        </script>   
	
	<!-- jQuery Easing -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.easing.1.3.js')"></script>
	<!-- Bootstrap -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/bootstrap.min.js')"></script>
	<!-- Waypoints -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.countTo.js	')"></script>
	
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.waypoints.min.js')"></script>
	<!-- Carousel -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/owl.carousel.min.js')"></script>
	

	<!-- Stellar Parallax -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.stellar.min.js')"></script>

	<!-- Magnific Popup -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/jquery.magnific-popup.min.js')"></script>
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/magnific-popup-options.js') "></script>
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.14.1/moment.min.js"></script>
	

	<script src="https://cdn.jsdelivr.net/toastr/2.1.3/toastr.min.js"></script>
	<!-- Main -->
	<script src="@plugin_asset('LandingPagesPlugin/Trendy/js/main.js')"></script>
	
	
	

	</body>
</html>

